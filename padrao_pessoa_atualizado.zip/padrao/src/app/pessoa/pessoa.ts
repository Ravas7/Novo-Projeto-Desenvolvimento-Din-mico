import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

interface PessoaForm {
  nomeCompleto: string;
  dataNascimento: string;
  cpf: string;
  rg: string;
  nomeMae: string;
  nomePai: string;
  paisOrigem: string;
  ufOrigem: string;
  cidadeOrigem: string;
}

@Component({
  selector: 'app-pessoa',
  imports: [FormsModule],
  templateUrl: './pessoa.html',
  styleUrl: './pessoa.css'
})
export class Pessoa {
  readonly titulo = 'Cadastro de Pessoa';

  pessoa: PessoaForm = this.pessoaEmBranco();

  salvou = false;

  private pessoaEmBranco(): PessoaForm {
    return {
      nomeCompleto: '',
      dataNascimento: '',
      cpf: '',
      rg: '',
      nomeMae: '',
      nomePai: '',
      paisOrigem: '',
      ufOrigem: '',
      cidadeOrigem: ''
    };
  }

  salvar(): void {
    this.salvou = true;
  }

  limpar(): void {
    this.pessoa = this.pessoaEmBranco();
    this.salvou = false;
  }
}
